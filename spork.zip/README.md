# Spork
Spork is an entity-component framework.

## Core parts:
Under construction...

## Example project:
https://github.com/Skyfire2008/sporkExample